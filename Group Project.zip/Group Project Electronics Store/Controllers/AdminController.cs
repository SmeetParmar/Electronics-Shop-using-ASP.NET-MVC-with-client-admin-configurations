﻿using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Group_Project_Electronics_Store.Data;
using Group_Project_Electronics_Store.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Reflection.Metadata;

namespace Group_Project_Electronics_Store.Controllers
{
    public class AdminController : Controller
    {
        private readonly ILogger<AdminController> _logger;
        private readonly Context_Model _context;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public AdminController(ILogger<AdminController> logger, Context_Model context, IWebHostEnvironment webHostEnvironment)
        {
            _logger = logger;
            _context = context;
            _webHostEnvironment = webHostEnvironment;
        }

        // GET: Admin/AddProduct
        public async Task<IActionResult> AddProduct(int? id)
        {
            if (id == null)
            {
                // Create new product
                var categories = await _context.Categories.ToListAsync();
                ViewBag.CategoryList = new SelectList(categories, "CategoryID", "CategoryName");
                return View(new Product_Model());
            }
            else
            {
                // Edit existing product
                var product = await _context.Products.FindAsync(id);
                if (product == null)
                {
                    return NotFound();
                }

                var categories = await _context.Categories.ToListAsync();
                ViewBag.CategoryList = new SelectList(categories, "CategoryID", "CategoryName");
                return View(product);
            }
        }


       // POST: AddProduct(Handles both Add and Edit)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddProduct(int id, Product_Model product, IFormFile imageFile)
        {
            // Check if the image file is not provided
            if (imageFile == null)
            {
                // Add a model error for the Image field
                ModelState.AddModelError("Image", "Image is required.");
            }

            if (imageFile != null)
            {
                // Generate a unique file name for the image
                var fileName = Path.GetFileNameWithoutExtension(imageFile.FileName);
                var extension = Path.GetExtension(imageFile.FileName);
                var uniqueFileName = $"{fileName}_{Guid.NewGuid()}{extension}";

                // Set the path to save the image in the wwwroot/images folder
                var path = Path.Combine(_webHostEnvironment.WebRootPath, "images", uniqueFileName);

                // Save the image file to the specified path
                using (var fileStream = new FileStream(path, FileMode.Create))
                {
                    await imageFile.CopyToAsync(fileStream);
                }

                // Save the image file name to the product model
                product.Image = uniqueFileName;
            }

            if (id == 0)
            {
                // Add new product
                _context.Products.Add(product);
                TempData["SuccessMsg"] = "Product Added Successfully.";
            }
            else
            {
                // Edit existing product
                _context.Products.Update(product);
                TempData["SuccessMsg"] = "Product Updated Successfully.";
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(ManageProducts));
        }


        public async Task<IActionResult> DeleteProduct(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            // Delete the image file from the wwwroot/images folder
            var imagePath = Path.Combine(_webHostEnvironment.WebRootPath, "images", product.Image);
            if (System.IO.File.Exists(imagePath))
            {
                System.IO.File.Delete(imagePath);
            }

            TempData["SuccessMsg"] = "Product Deleted Successfully.";
            // Remove the product from the database
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(ManageProducts));
        }

        public async Task<IActionResult> DeleteCategory(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Find the category by ID
            var category = await _context.Categories.FindAsync(id);
            if (category == null)
            {
                return NotFound();
            }

            // Check if any products are associated with this category
            bool hasProducts = await _context.Products.AnyAsync(p => p.CategoryID == id);
            if (hasProducts)
            {
                // If products exist, do not delete the category and display a warning message
                TempData["Error"] = "Cannot delete this category because it has associated products.";
                return RedirectToAction(nameof(ManageCategories));
            }

            TempData["SuccessMsg"] = "Category Deleted Successfully.";
            // If no products are associated, proceed with the deletion
            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(ManageCategories));
        }


        // GET: AddCategory
        public async Task<IActionResult> AddCategory(int? id)
        {
            if (id == null)
            {
                // If no id is provided, create a new Category_Model object for adding a new category
                return View(new Category_Model());
            }

            // If id is provided, retrieve the category for editing
            var category = await _context.Categories.FindAsync(id);
            if (category == null)
            {
                return NotFound();
            }

            return View(category);
        }

        // POST: AddCategory
        [HttpPost]
        public async Task<IActionResult> AddCategory(Category_Model category)
        {
            if (ModelState.IsValid)
            {
                if (category.CategoryID == 0)
                {
                    // If CategoryID is 0, add a new category
                    _context.Categories.Add(category);
                    TempData["SuccessMsg"] = "Category Added Successfully.";
                }
                else
                {
                    // Otherwise, update the existing category
                    _context.Categories.Update(category);
                    TempData["SuccessMsg"] = "Category Updated Successfully.";
                }

                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(ManageCategories));
            }

            return View(category);
        }

        public async Task<IActionResult> ManageProducts()
        {
            var products = await _context.Products
                                 .Include(p => p.Category)
                                 .ToListAsync();
            return View(products);
        }

        public async Task<IActionResult> ManageCategories()
        {
            var categories = await _context.Categories.ToListAsync();
            return View(categories);
        }

        public async Task<IActionResult> Feedbacks()
        {
            var feedbacks = await _context.Feedbacks.ToListAsync();
            return View(feedbacks);
        }

    }
}
