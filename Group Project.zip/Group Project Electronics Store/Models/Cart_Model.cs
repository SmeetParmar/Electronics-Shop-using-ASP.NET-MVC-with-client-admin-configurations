﻿using System.ComponentModel.DataAnnotations;

namespace Group_Project_Electronics_Store.Models
{
    public class Cart_Model
    {
        public int CartID { get; set; }

        [Required(ErrorMessage = "User ID is required.")]
        public int UserID { get; set; }
        public User_Model User { get; set; }

        [Required(ErrorMessage = "Product ID is required.")]
        public int ProductID { get; set; }
        public Product_Model Product { get; set; }

        [Required(ErrorMessage = "Quantity is required.")]
        public int Quantity { get; set; }
    }
}
