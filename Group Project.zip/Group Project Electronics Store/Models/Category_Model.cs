﻿using System.ComponentModel.DataAnnotations;

namespace Group_Project_Electronics_Store.Models
{
    public class Category_Model
    {
        public int CategoryID { get; set; }

        [Required(ErrorMessage = "Category name is required.")]
        public string CategoryName { get; set; }
    }
}
