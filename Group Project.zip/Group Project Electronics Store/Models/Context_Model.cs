﻿using Microsoft.EntityFrameworkCore;
using Group_Project_Electronics_Store.Models;

namespace Group_Project_Electronics_Store.Data
{
    public class Context_Model : DbContext
    {
        public Context_Model(DbContextOptions<Context_Model> options): base(options)
        {}

        public DbSet<User_Model> Users { get; set; }
        public DbSet<Product_Model> Products { get; set; }
        public DbSet<Category_Model> Categories { get; set; }
        public DbSet<Cart_Model> Carts { get; set; }
        public DbSet<Order_Model> Orders { get; set; }
        public DbSet<Order_Details_Model> OrderDetails { get; set; }
        public DbSet<Feedback_Model> Feedbacks { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User_Model>()
                .HasKey(u => u.UserID);

            modelBuilder.Entity<Product_Model>()
                .HasKey(p => p.ProductID);

            modelBuilder.Entity<Category_Model>()
                .HasKey(c => c.CategoryID);

            modelBuilder.Entity<Cart_Model>()
                .HasKey(c => c.CartID);

            modelBuilder.Entity<Cart_Model>()
                .HasOne(c => c.User)
                .WithMany()
                .HasForeignKey(c => c.UserID);

            modelBuilder.Entity<Cart_Model>()
                .HasOne(c => c.Product)
                .WithMany()
                .HasForeignKey(c => c.ProductID);

            modelBuilder.Entity<Order_Model>()
                .HasKey(o => o.OrderID);

            modelBuilder.Entity<Order_Model>()
                .HasOne(o => o.User)
                .WithMany()
                .HasForeignKey(o => o.UserID);

            modelBuilder.Entity<Order_Details_Model>()
                .HasKey(od => od.OrderDetailID);

            modelBuilder.Entity<Order_Details_Model>()
                .HasOne(od => od.Order)
                .WithMany()
                .HasForeignKey(od => od.OrderID);

            modelBuilder.Entity<Order_Details_Model>()
                .HasOne(od => od.Product)
                .WithMany()
                .HasForeignKey(od => od.ProductID);

            modelBuilder.Entity<Feedback_Model>()
                .HasKey(f => f.ID);

            modelBuilder.Entity<Category_Model>().HasData(
                new Category_Model { CategoryID = 1, CategoryName = "Laptop" },
                new Category_Model { CategoryID = 2, CategoryName = "Television" },
                new Category_Model { CategoryID = 3, CategoryName = "Phone" },
                new Category_Model { CategoryID = 4, CategoryName = "Tablet" },
                new Category_Model { CategoryID = 5, CategoryName = "Camera" }
            );

            // Seed Products
            modelBuilder.Entity<Product_Model>().HasData(
                new Product_Model
                {
                    ProductID = 1,
                    ProductName = "ASUS ROG Strix G16 16\" Gaming Laptop",
                    CategoryID = 1,
                    Description = "Raise your game and carry your squad with the ASUS ROG Strix G16, a powerful 16\" gaming laptop that features Windows 11, a 13th Gen Intel Core i7-13650HX processor, and an NVIDIA GeForce RTX 4050 GPU. With 32GB DDR5 memory and 512GB SSD storage, this laptop is designed to provide lightning-fast performance and minimize loading times.",
                    Price = 1899.89m,
                    Image = "Laptop2_1_e2da3c62-3997-405a-bd44-63c5a2684fcb.jpg"
                },
                new Product_Model
                {
                    ProductID = 2,
                    ProductName = "Apple iPad 10.9\" 64GB with Wi-Fi 6",
                    CategoryID = 4,
                    Description = "The Apple iPad 10th Generation is colourfully reimagined to be more capable, more intuitive, and even more fun. With a new all‑screen design, 10.9-inch Liquid Retina display, and four gorgeous colours, iPad delivers a powerful way to get things done, create, and stay connected. Add on essential accessories designed just for iPad and enjoy endless versatility for everything you love to do.",
                    Price = 459.99m,
                    Image = "Tab2_1_66bf338a-03c9-4521-8b4c-a5620f0b754f.jpg"
                },
                new Product_Model
                {
                    ProductID = 3,
                    ProductName = "Samsung 43\" 4K UHD HDR LED Tizen Smart TV",
                    CategoryID = 2,
                    Description = "Immerse yourself in spectacular visuals with this Samsung LED Smart TV. It features 4K Ultra HD resolution and 60Hz refresh rate for crisp and clear picture quality with smooth visuals. Plus, 4K upscaling improves the quality of low-resolution content to almost 4K resolution. The Tizen OS provides user-friendly interface and more entertainment options.",
                    Price = 599.99m,
                    Image = "TV2_1_0f4b24bd-2dbf-4c89-b64a-808dc8e4a4bb.jpg"
                },
                new Product_Model
                {
                    ProductID = 4,
                    ProductName = "Apple iPhone 15 128GB - Black",
                    CategoryID = 3,
                    Description = "The Apple iPhone 15 brings you Dynamic Island, a 48MP main camera with 2X Telephoto, and USB-C—all in a durable colour-infused glass and aluminum design. It features a 6.1\" Super Retina XDR display which is up to 2x brighter in the sun compared to iPhone 14.",
                    Price = 1189.89m,
                    Image = "Phone1_1_ad83a2d3-a2bd-4ee0-8afa-adc65525fe6f.jpeg"
                },
                new Product_Model
                {
                    ProductID = 5,
                    ProductName = "Canon EOS Rebel T7 DSLR Camera with 18-55mm Focus Lens",
                    CategoryID = 5,
                    Description = "Take your photography to the next level with the Canon EOS Rebel T7 DSLR Camera. This 24.1MP device will easily allow you to take high quality images that you can share with the whole world. Its easy-to-use operation allows you to capture every moment as it happens and not be limited to blurry or washed-out point-and-shoot pictures.",
                    Price = 329.89m,
                    Image = "Camera1_1_73450e5a-cb8f-4640-a69d-6f3d7210d5ba.jpg"
                }
            );

            base.OnModelCreating(modelBuilder);
        }
    }
}
