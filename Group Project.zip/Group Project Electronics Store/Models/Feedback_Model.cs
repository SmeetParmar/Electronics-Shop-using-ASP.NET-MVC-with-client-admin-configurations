﻿using System.ComponentModel.DataAnnotations;

namespace Group_Project_Electronics_Store.Models
{
    public class Feedback_Model
    {
        [Key]
        public int ID { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email address format.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Message is required.")]
        public string Message { get; set; }
    }
}
