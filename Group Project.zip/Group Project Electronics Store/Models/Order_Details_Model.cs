﻿using System.ComponentModel.DataAnnotations;

namespace Group_Project_Electronics_Store.Models
{
    public class Order_Details_Model
    {
        [Key]
        public int OrderDetailID { get; set; }

        [Required(ErrorMessage = "Order ID is required.")]
        public int OrderID { get; set; }

        [Required(ErrorMessage = "Product ID is required.")]
        public int ProductID { get; set; }

        [Required(ErrorMessage = "Quantity is required.")]
        [Range(1, int.MaxValue, ErrorMessage = "Quantity must be a positive number.")]
        public int Quantity { get; set; }

        [Required(ErrorMessage = "Price is required.")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Price must be a positive number.")]
        public decimal Price { get; set; }

        // Navigation properties
        public Order_Model Order { get; set; }
        public Product_Model Product { get; set; }
    }
}
