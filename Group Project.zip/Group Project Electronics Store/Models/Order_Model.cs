﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Group_Project_Electronics_Store.Models
{
    public class Order_Model
    {
        public int OrderID { get; set; }

        [Required(ErrorMessage = "User ID is required.")]
        public int UserID { get; set; }

        public User_Model User { get; set; }

        [Required(ErrorMessage = "Order date is required.")]
        public DateTime OrderDate { get; set; }

        [Required(ErrorMessage = "Total amount is required.")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Total amount must be a positive number.")]
        public decimal TotalAmount { get; set; }

        [Required(ErrorMessage = "Shipping address is required.")]
        public string ShippingAddress { get; set; }

        [Required(ErrorMessage = "City is required.")]
        public string ShippingCity { get; set; }

        [Required(ErrorMessage = "State is required.")]
        public string ShippingState { get; set; }

        [Required(ErrorMessage = "Postal code is required.")]
        public string ShippingPostalCode { get; set; }

        [Required(ErrorMessage = "Country is required.")]
        public string ShippingCountry { get; set; }

        [Required(ErrorMessage = "First name is required.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last name is required.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email address format.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Phone number is required.")]
        [Phone(ErrorMessage = "Invalid phone number format.")]
        [StringLength(15, ErrorMessage = "Phone number cannot be longer than 15 characters.")]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessage = "Card number is required.")]
        [CreditCard(ErrorMessage = "Invalid credit card number format.")]
        public string CardNumber { get; set; }

        [Required(ErrorMessage = "Card holder name is required.")]
        public string CardHolderName { get; set; }

        [Required(ErrorMessage = "Card expiration date is required.")]
        [RegularExpression(@"^(0[1-9]|1[0-2])\/\d{2}$", ErrorMessage = "Card expiration date must be in MM/YY format.")]
        public string CardExpirationDate { get; set; }

        [Required(ErrorMessage = "Card security code is required.")]
        [StringLength(3, ErrorMessage = "Card security code cannot be longer than 3 characters.")]
        public string CardSecurityCode { get; set; }
    }
}
