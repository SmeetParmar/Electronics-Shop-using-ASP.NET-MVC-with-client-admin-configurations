﻿using System.ComponentModel.DataAnnotations;

namespace Group_Project_Electronics_Store.Models
{
    public class User_Model
    {
        public int UserID { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email address format.")]
        [StringLength(100, ErrorMessage = "Email cannot be longer than 100 characters.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [RegularExpression(@"^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?\[\]{}|;':""\-_+]).+$",
            ErrorMessage = "Password must contain at least one alphabetic character, one numeric digit, and one special character.")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Role is required.")]
        public string Role { get; set; }
    }
}
